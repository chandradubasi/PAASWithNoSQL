﻿using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.IRepository
{
    public interface ILabsRepository
    {
        Task<Lab> CreateLabAsync(Lab lab);
        Task<List<Lab>> GetLabs();
        Task<LabsResponse> GetLab(string labID);
    }
}
