﻿using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.IServices
{
   public interface IStorageServices
    {
        Task<Storage> CreateStorageAsync(Storage storage);
        Task<List<Storage>> GetStorages();
        Task<StoragesResponse> GetStoragesById(string storageId);

    }
}
