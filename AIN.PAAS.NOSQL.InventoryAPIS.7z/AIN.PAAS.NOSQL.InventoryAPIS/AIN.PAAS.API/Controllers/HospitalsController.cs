﻿using AIN.PAAS.Helper.Constants;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;


namespace AIN.PAAS.API.Controllers
{
    [Route(CommonConstants.Hospital.HospitalAPIControllerRoute)]
    [ApiController]
    public class HospitalsController : ControllerBase
    {
        private IHospitalService _hospitalService;

        public HospitalsController(IHospitalService hospitalService)
        {
            _hospitalService = hospitalService;
        }

        [HttpPost]        
        public async Task<IActionResult> Post(Hospital hospital)
        {
            try
            {
                var results = await _hospitalService.CreateHospitalAsync(hospital);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpGet]        
        public async Task<ActionResult<IEnumerable<HospitalsResponse>>> Get()
        {
            try
            {
                var hospitalResponseList = await _hospitalService.GetHospital();
                if (hospitalResponseList != null)
                {
                    return new OkObjectResult(hospitalResponseList);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }
    }
}
