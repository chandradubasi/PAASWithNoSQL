﻿using AIN.PAAS.Helper.Constants;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace AIN.PAAS.API.Controllers
{
    [Route(CommonConstants.Site.SiteAPIControllerRoute)]
    [ApiController]
    public class SitesController : ControllerBase
    {
        private ISitesService _sitesService;

        public SitesController(ISitesService sitesService)
        {
            _sitesService = sitesService;
        }
        [HttpPost]        
        public async Task<IActionResult> Post(Site site)
        {
            try
            {
                var results = await _sitesService.CreateSiteAsync(site);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpGet]
        //[Route(CommonConstants.Site.AllSites)]
        public async Task<ActionResult<Site>> Get()
        {
            try
            {
                var sites = await _sitesService.Getsites();
                if (sites != null)
                {
                    return new OkObjectResult(sites);
                }
                else
                {
                    return new BadRequestResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpGet]
        [Route(CommonConstants.Site.GetSiteById)]
        public async Task<ActionResult<SitesResponse>> Get(string siteId)
        {
            try
            {
                var sitesResponseList = await _sitesService.Getsite(siteId);
                if (sitesResponseList != null)
                {
                    return new OkObjectResult(sitesResponseList);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }
    }
}
