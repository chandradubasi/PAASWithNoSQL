﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.Repository
{
    public class SitesRepository : ISitesRepository
    {
        private readonly IMongoCollection<Site> _site;
        private readonly IMongoCollection<Lab> _lab;
        private readonly RegionConfigs _regionConfigs;

        public SitesRepository(IAINInventoryDatabaseSettings settings, IOptions<RegionConfigs> regionConfigs)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);            
            _site = database.GetCollection<Site>(settings.SiteCollectionName);
            _lab = database.GetCollection<Lab>(settings.LabCollectionName);
            _regionConfigs = regionConfigs.Value;
        }

        public async Task<Site> CreateSiteAsync(Site site)
        {
            await _site.InsertOneAsync(site);
            return site;
        }

        public async Task<SitesResponse> Getsite(string siteID)
        {
            SitesResponse sitesResponse = null;
            try
            {
                var sites = await _site.Find(s => s.Id == siteID).FirstOrDefaultAsync();
                var labs = await _lab.Find(s => s.SiteID == siteID).ToListAsync();

                if (sites != null)
                {
                    sitesResponse = new SitesResponse()
                    {
                        SiteId = sites.Id,
                        Name = sites.Name,
                        Labs = labs.Select(e => _regionConfigs.APIDomain + "/api/labs/" + e.Id).ToArray()
                    };
                }
                return sitesResponse;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task<List<Site>> Getsites()
        {
            return await _site.Find(s => true).ToListAsync();
        }
    }
}
