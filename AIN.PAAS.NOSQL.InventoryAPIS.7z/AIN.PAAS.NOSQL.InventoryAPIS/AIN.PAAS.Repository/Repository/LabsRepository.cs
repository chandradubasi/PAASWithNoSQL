﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.Repository
{
    public class LabsRepository : ILabsRepository
    {
        private readonly IMongoCollection<Lab> _lab;
        private readonly IMongoCollection<Location> _location;
        private readonly RegionConfigs _regionConfigs;

        public LabsRepository(IAINInventoryDatabaseSettings settings, IOptions<RegionConfigs> regionConfigs)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _lab = database.GetCollection<Lab>(settings.LabCollectionName);
            _location = database.GetCollection<Location>(settings.LocationCollectionName);
            _regionConfigs = regionConfigs.Value;

        }
        public async Task<Lab> CreateLabAsync(Lab lab)
        {
            await _lab.InsertOneAsync(lab);
            return lab;
        }

        public async Task<LabsResponse> GetLab(string labID)
        {
            LabsResponse labsResponse = null;
            try
            {
                var lab = await _lab.Find(s => s.Id == labID).FirstOrDefaultAsync();
                var locations = await _location.Find(s => s.LabID == labID).ToListAsync();

                if (lab != null)
                {
                    labsResponse = new LabsResponse()
                    {
                        LabId = lab.Id,
                        Name = lab.Name,
                        Locations = locations.Select(e => _regionConfigs.APIDomain + "/api/locations/" + e.Id).ToArray()
                    };

                }
                return labsResponse;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task<List<Lab>> GetLabs()
        {
            return await _lab.Find(s => true).ToListAsync();
        }
    }
}
