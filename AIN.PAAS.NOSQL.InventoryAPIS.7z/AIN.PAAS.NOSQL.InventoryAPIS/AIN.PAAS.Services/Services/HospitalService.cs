﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.Services
{
    public class HospitalService : IHospitalService
    {
        private IHospitalRepository _hospitalRepository;
        public HospitalService(IHospitalRepository hospitalRepository)
        {
            _hospitalRepository = hospitalRepository;
        }
        public async Task<Hospital> CreateHospitalAsync(Hospital hospitalRequest)
        {
            return await _hospitalRepository.CreateHospitalAsync(hospitalRequest);
        }

        public async Task<List<HospitalsResponse>> GetHospital()
        {
            return await _hospitalRepository.GetHospital();            
        }
    }
}
