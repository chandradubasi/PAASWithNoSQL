﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.Services
{
    public class StorageServices : IStorageServices
    {
        private IStorageRepository _storageRepository;
        public StorageServices(IStorageRepository storageRepository)
        {
            _storageRepository = storageRepository;

        }
        public async Task<Storage> CreateStorageAsync(Storage storage)
        {
            return await _storageRepository.CreateStorageAsync(storage);
        }

        public async Task<List<Storage>> GetStorages()
        {
            return await _storageRepository.GetStorages();
        }

        public async Task<StoragesResponse> GetStoragesById(string storageId)
        {
            return await _storageRepository.GetStoragesById(storageId);
        }
    }
}
