﻿using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using AIN.PAAS.ViewModel.Models.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.IServices
{
    public interface IInventoryAPIServices
    {
        Task<Hospital> CreateHospitalAsync(Hospital hospitalRequest);
        Task<List<HospitalsResponse>> GetHospital();
        Task<Site> CreateSiteAsync(Site site);
        Task<List<Site>> Getsites();
        Task<SitesResponse> Getsite(string siteID);
        Task<Lab> CreateLabAsync(Lab lab);
        Task<List<Lab>> GetLabs();
        Task<LabsResponse> GetLab(string labID);
        Task<Location> CreateLocationAsync(Location location);
        Task<LocationsResponse> GetLocationsById(string locationId);
        Task<Storage> CreateStorageAsync(Storage storage);
        Task<List<Storage>> GetStorages();
        Task<StoragesResponse> GetStoragesById(string storageId);
        Task<Product> CreateProductAsync(Product product);
        Task<CheckInResponse> InventoryCheckIn(CheckInRequest checkInRequest);
        Task<List<InventoryItem>> GetInventoryByStatus(string status);
        Task<InventoryItem> InventoryCheckOut(CheckOutRequest checkOutRequest);
        Task<TransferRequestData> ItemTransfer(TransferRequestData transferRequestData);

    }
}
