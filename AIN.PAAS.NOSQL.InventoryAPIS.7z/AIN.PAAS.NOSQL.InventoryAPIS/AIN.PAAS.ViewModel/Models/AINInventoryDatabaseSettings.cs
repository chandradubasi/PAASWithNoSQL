﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIN.PAAS.ViewModel.Models
{
    public class AINInventoryDatabaseSettings : IAINInventoryDatabaseSettings
    {
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
        public string CheckInRequestCollectionName { get; set; }
        public string InventoryHospitalCollectionName { get; set; }
        public string HospitalCollectionName { get; set; }
        public string SiteCollectionName { get; set; }
        public string LabCollectionName { get; set; }
        public string LocationCollectionName { get; set; }
        public string StorageCollectionName { get; set; }
        public string InventoryCollectionName { get; set; }
        public string ProductCollectionName { get; set; }
        public string TransferCollectionName { get; set; }
        public string APIDomain { get; set; }

    }
}
