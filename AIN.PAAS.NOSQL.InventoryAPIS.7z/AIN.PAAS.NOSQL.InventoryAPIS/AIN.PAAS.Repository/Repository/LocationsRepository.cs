﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.Repository
{
    public class LocationsRepository : ILocationsRepository
    {
        private readonly IMongoCollection<Location> _location;
        private readonly IMongoCollection<Storage> _storage;
        private readonly RegionConfigs _regionConfigs;

        public LocationsRepository(IAINInventoryDatabaseSettings settings, IOptions<RegionConfigs> regionConfigs)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _location = database.GetCollection<Location>(settings.LocationCollectionName);
            _storage = database.GetCollection<Storage>(settings.StorageCollectionName);
            _regionConfigs = regionConfigs.Value;
        }
        public async Task<Location> CreateLocationAsync(Location location)
        {
            await _location.InsertOneAsync(location);
            return location;
        }

        public async Task<LocationsResponse> GetLocationsById(string locationId)
        {
            LocationsResponse locationResponse = null;
            try
            {
                var location = await _location.Find(s => s.Id == locationId).FirstOrDefaultAsync();
                var storages = await _storage.Find(s => s.LocationId == locationId).ToListAsync();

                if (location != null)
                {
                    locationResponse = new LocationsResponse()
                    {
                        LocationId = location.Id,
                        Name = location.Name,
                        Storages = storages.Select(e => _regionConfigs.APIDomain + "/api/storages/" + e.Id).ToArray()
                    };

                }
                return locationResponse;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
