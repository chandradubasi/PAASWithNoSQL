﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIN.PAAS.ViewModel.Models
{
   public class Vendor
    {

    }
}
