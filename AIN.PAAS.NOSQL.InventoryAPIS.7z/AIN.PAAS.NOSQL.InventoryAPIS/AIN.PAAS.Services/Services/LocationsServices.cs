﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.Services
{
    public class LocationsServices : ILocationsServices
    {
        private ILocationsRepository _locationsRepository;

        public LocationsServices(ILocationsRepository locationsRepository)
        {
            _locationsRepository = locationsRepository;
        }
        public async Task<Location> CreateLocationAsync(Location location)
        {
            return await _locationsRepository.CreateLocationAsync(location);
        }

        public async Task<LocationsResponse> GetLocationsById(string locationId)
        {
            return await _locationsRepository.GetLocationsById(locationId);
        }
    }
}
