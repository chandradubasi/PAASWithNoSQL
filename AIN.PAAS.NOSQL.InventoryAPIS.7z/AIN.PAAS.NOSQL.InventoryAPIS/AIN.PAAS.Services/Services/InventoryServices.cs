﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.Services
{
    public class InventoryServices : IInventoryServices
    {
        private IInventoryRepository  _inventoryRepository;
        public InventoryServices(IInventoryRepository inventoryRepository)
        {
            _inventoryRepository = inventoryRepository;
        }
        public async Task<List<InventoryItem>> GetInventoryByStatus(string status)
        {
            return await _inventoryRepository.GetInventoryByStatus(status);
        }

        public async Task<CheckInResponse> InventoryCheckIn(CheckInRequest checkInRequest)
        {
            return await _inventoryRepository.InventoryCheckIn(checkInRequest);
        }

        public async Task<InventoryItem> InventoryCheckOut(CheckOutRequest checkOutRequest)
        {
            return await _inventoryRepository.InventoryCheckOut(checkOutRequest);
        }

        public async Task<TransferRequestData> ItemTransfer(TransferRequestData transferRequestData)
        {
            return await _inventoryRepository.ItemTransfer(transferRequestData);
        }
    }
}
