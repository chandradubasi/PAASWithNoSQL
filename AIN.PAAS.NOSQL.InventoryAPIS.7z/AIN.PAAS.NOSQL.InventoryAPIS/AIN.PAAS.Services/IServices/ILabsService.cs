﻿using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.IServices
{
    public interface ILabsService
    {
        Task<Lab> CreateLabAsync(Lab lab);
        Task<List<Lab>> GetLabs();
        Task<LabsResponse> GetLab(string labID);
    }
}
