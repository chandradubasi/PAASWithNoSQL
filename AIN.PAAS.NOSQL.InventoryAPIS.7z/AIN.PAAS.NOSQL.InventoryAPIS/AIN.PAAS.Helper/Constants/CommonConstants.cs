﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIN.PAAS.Helper.Constants
{
    public static class CommonConstants
    {

        public class Hospital
        {
            public const string HospitalAPIControllerRoute = "api/Hospitals";
            public const string CreateHospitalRoute = "createhospital";
            public const string GetHospitals = "hospitals";
        }
        public class Site
        {
            public const string SiteAPIControllerRoute = "api/Sites";
            public const string CreateSiteRoute = "createsite";
            public const string GetSiteById = "siteId";
            public const string AllSites = "getallsites";
        }

        public class Lab
        {
            public const string LabAPIControllerRoute = "api/Labs";
            public const string CreateLabRoute = "createlab";
            public const string GetLabById = "labId";
            public const string AllLabs = "getalllabs";
        }

        public class Location
        {
            public const string LocationsAPIControllerRoute = "api/Locations";
            public const string CreateLocationRoute = "createlocation";
            public const string GetLocationById = "locationId";
            public const string AllLocations = "getalllocations";
        }

        public class Storage
        {
            public const string LocationsAPIControllerRoute = "api/Storages";
            public const string CreateStorageRoute = "createstorage";
            public const string GetStorageById = "storageId";
            public const string AllStorages = "getallstorages";

        }
        public class Inventory
        {
            public const string InventoryAPIControllerRoute = "api/inventory";
            public const string CreateInventoryRoute = "workflows/checkin";
            public const string CheckOutInventoryRoute = "workflows/checkout";
            public const string GetInventoryByStatus = "{status}";
            public const string InventoryTransfer = "workflows/transfer";

        }
        public class Product
        {
            public const string ProductAPIControllerRoute = "api/Products";
            public const string CreateProductRoute = "createproduct";

        }

        public class APIConstant
        {
            public const string InternalServerError = "Internal Server Error";

        }

    }
}
