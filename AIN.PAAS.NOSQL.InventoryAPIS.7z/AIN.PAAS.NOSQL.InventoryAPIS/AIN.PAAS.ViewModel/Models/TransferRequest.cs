﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace AIN.PAAS.ViewModel.Models
{
    public class TransferRequest
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        public string Items { get; set; }
        public string SourceId { get; set; }
        public string DestinationId { get; set; }
        public string Requester { get; set; }
        public DateTime? RequestedDate { get; set; }
        public string Approver { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }
        public DateTime? CreatedDate { get; set; }

    }
}
