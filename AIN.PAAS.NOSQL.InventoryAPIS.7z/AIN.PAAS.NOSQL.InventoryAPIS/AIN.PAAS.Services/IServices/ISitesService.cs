﻿using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.IServices
{
    public interface ISitesService
    {
        Task<Site> CreateSiteAsync(Site site);
        Task<List<Site>> Getsites();
        Task<SitesResponse> Getsite(string siteID);
    }
}
