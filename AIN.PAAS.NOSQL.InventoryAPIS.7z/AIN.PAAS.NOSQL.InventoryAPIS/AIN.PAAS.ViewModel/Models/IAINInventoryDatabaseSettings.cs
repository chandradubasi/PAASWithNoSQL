﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIN.PAAS.ViewModel.Models
{
    public interface IAINInventoryDatabaseSettings
    {
        string ConnectionString { get; set; }
        string DatabaseName { get; set; }
        string CheckInRequestCollectionName { get; set; }
        string InventoryHospitalCollectionName { get; set; }
        string HospitalCollectionName { get; set; }
        string SiteCollectionName { get; set; }
        string LabCollectionName { get; set; }
        string LocationCollectionName { get; set; }
        string StorageCollectionName { get; set; }
        string InventoryCollectionName { get; set; }
        string ProductCollectionName { get; set; }
        string TransferCollectionName { get; set; }
        string APIDomain { get; set; }
    }
}
