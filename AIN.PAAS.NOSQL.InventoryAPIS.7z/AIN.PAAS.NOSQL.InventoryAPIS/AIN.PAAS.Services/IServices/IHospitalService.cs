﻿using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.IServices
{
    public interface IHospitalService
    {
        Task<Hospital> CreateHospitalAsync(Hospital hospitalRequest);
        Task<List<HospitalsResponse>> GetHospital();
    }
}
