﻿using AIN.PAAS.Helper.Constants;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;

namespace AIN.PAAS.API.Controllers
{
    [Route(CommonConstants.Location.LocationsAPIControllerRoute)]
    [ApiController]
    public class LocationsController : ControllerBase
    {
        private ILocationsServices _locationsServices;


        public LocationsController(ILocationsServices locationsServices)
        {
            _locationsServices = locationsServices;
        }

        [HttpPost]        
        public async Task<IActionResult> Post(Location location)
        {
            try
            {
                var results = await _locationsServices.CreateLocationAsync(location);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpGet]
        [Route(CommonConstants.Location.GetLocationById)]
        public async Task<ActionResult<LocationsResponse>> Get(string locationId)
        {
            try
            {
                var locationResponse = await _locationsServices.GetLocationsById(locationId);
                if (locationResponse != null)
                {
                    return new OkObjectResult(locationResponse);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }
    }
}
