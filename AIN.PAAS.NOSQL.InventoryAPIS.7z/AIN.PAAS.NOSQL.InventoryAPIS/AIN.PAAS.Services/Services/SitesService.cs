﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.Services
{
    public class SitesService : ISitesService
    {
        private ISitesRepository _sitesRepository;

        public SitesService(ISitesRepository sitesRepository)
        {
            _sitesRepository = sitesRepository;
        }

        public async Task<Site> CreateSiteAsync(Site site)
        {
            return await _sitesRepository.CreateSiteAsync(site);
        }

        public async Task<SitesResponse> Getsite(string siteID)
        {
            return await _sitesRepository.Getsite(siteID);
        }

        public async Task<List<Site>> Getsites()
        {
            return await _sitesRepository.Getsites();
        }
    }
}
