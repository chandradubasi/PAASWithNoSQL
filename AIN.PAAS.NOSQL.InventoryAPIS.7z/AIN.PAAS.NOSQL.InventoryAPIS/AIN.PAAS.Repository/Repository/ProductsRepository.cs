﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.ViewModel.Models;
using MongoDB.Driver;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.Repository
{
    public class ProductsRepository : IProductsRepository
    {        
        private readonly IMongoCollection<Product> _product;
        public ProductsRepository(IAINInventoryDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _product = database.GetCollection<Product>(settings.ProductCollectionName);
        }
        public async Task<Product> CreateProductAsync(Product product)
        {
            await _product.InsertOneAsync(product);
            return product;
        }
    }
}
