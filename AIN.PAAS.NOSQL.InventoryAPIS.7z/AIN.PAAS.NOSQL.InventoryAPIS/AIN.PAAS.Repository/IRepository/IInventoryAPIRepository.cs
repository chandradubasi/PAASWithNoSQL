﻿using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using AIN.PAAS.ViewModel.Models.Response;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.IRepository
{
    public interface IInventoryAPIRepository
    {
        Task<Hospital> CreateHospitalAsync(Hospital hospitalRequest);
        Task<List<HospitalsResponse>> GetHospital();
        Task<Site> CreateSiteAsync(Site site);
        Task<List<Site>> Getsites();
        Task<SitesResponse> Getsite(string siteID);
        Task<Lab> CreateLabAsync(Lab lab);
        Task<List<Lab>> GetLabs();      
        Task<LabsResponse> GetLab(string labID);
        Task<Location> CreateLocationAsync(Location location);       
        Task<LocationsResponse> GetLocationsById(string locationId);        
        Task<Storage> CreateStorageAsync(Storage storage);
        Task<List<Storage>> GetStorages();
        Task<StoragesResponse> GetStoragesById(string storageId);        
        Task<Product> CreateProductAsync(Product product);
        Task<CheckInResponse> InventoryCheckIn(CheckInRequest checkInRequest);
        Task<InventoryItem> InventoryCheckOut(CheckOutRequest checkOutRequest); 
        Task<InventoryItem> GetInventoryBySGTIN(string SGTIN);
        Task<List<InventoryItem>> GetInventoryByStatus(string status);
        Task CheckoutUpdateAsync(string id, InventoryItem checkoutinventory);
        Task<InventoryItem> GetInventoryByIDStorageID(TransferRequestData transferRequestData, int itreationitem);
        Task<TransferRequestData> ItemTransfer(TransferRequestData transferRequestData);
    }
}
