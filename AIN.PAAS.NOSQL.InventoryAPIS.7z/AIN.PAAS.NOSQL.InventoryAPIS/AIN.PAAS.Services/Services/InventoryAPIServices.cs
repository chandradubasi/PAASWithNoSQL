﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.Services
{
    public class InventoryAPIServices : IInventoryAPIServices
    {
        IInventoryAPIRepository inventoryAPIRepository;
        public InventoryAPIServices(IInventoryAPIRepository _inventoryAPIRepository)
        {
            inventoryAPIRepository = _inventoryAPIRepository;
        }
        public async Task<Hospital> CreateHospitalAsync(Hospital hospitalRequest)
        {
            return await inventoryAPIRepository.CreateHospitalAsync(hospitalRequest);
        }
        public async Task<Lab> CreateLabAsync(Lab lab)
        {
            return await inventoryAPIRepository.CreateLabAsync(lab);
        }
        public async Task<Location> CreateLocationAsync(Location location)
        {
            return await inventoryAPIRepository.CreateLocationAsync(location);
        }
        public async Task<Product> CreateProductAsync(Product product)
        {
            return await inventoryAPIRepository.CreateProductAsync(product);
        }
        public async Task<Site> CreateSiteAsync(Site site)
        {
            return await inventoryAPIRepository.CreateSiteAsync(site);
        }
        public async Task<Storage> CreateStorageAsync(Storage storage)
        {
            return await inventoryAPIRepository.CreateStorageAsync(storage);
        }
        public async Task<List<HospitalsResponse>> GetHospital()
        {
            return await inventoryAPIRepository.GetHospital();
        }
        public async Task<List<InventoryItem>> GetInventoryByStatus(string status)
        {
            return await inventoryAPIRepository.GetInventoryByStatus(status);
        }
        public async Task<LabsResponse> GetLab(string labID)
        {
            return await inventoryAPIRepository.GetLab(labID);
        }
        public async Task<List<Lab>> GetLabs()
        {
            return await inventoryAPIRepository.GetLabs();
        }
        public async Task<LocationsResponse> GetLocationsById(string locationId)
        {
            return await inventoryAPIRepository.GetLocationsById(locationId);
        }
        public async Task<SitesResponse> Getsite(string siteID)
        {
            return await inventoryAPIRepository.Getsite(siteID);
        }
        public async Task<List<Site>> Getsites()
        {
            return await inventoryAPIRepository.Getsites();
        }
        public async Task<List<Storage>> GetStorages()
        {
            return await inventoryAPIRepository.GetStorages();
        }
        public async Task<StoragesResponse> GetStoragesById(string storageId)
        {
            return await inventoryAPIRepository.GetStoragesById(storageId);
        }
        public async Task<CheckInResponse> InventoryCheckIn(CheckInRequest checkInRequest)
        {
            return await inventoryAPIRepository.InventoryCheckIn(checkInRequest);
        }
        public async Task<InventoryItem> InventoryCheckOut(CheckOutRequest checkOutRequest)
        {
            return await inventoryAPIRepository.InventoryCheckOut(checkOutRequest);
        }
        public async Task<TransferRequestData> ItemTransfer(TransferRequestData transferRequestData)
        {
            return await inventoryAPIRepository.ItemTransfer(transferRequestData);
        }
    }
}
