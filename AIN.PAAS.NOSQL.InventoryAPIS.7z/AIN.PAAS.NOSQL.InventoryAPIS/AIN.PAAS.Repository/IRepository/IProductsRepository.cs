﻿using AIN.PAAS.ViewModel.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.IRepository
{
    public interface IProductsRepository
    {
        Task<Product> CreateProductAsync(Product product);
    }
}
