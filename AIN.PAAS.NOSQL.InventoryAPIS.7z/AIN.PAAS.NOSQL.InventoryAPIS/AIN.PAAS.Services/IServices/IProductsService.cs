﻿using AIN.PAAS.ViewModel.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.IServices
{
   public interface IProductsService
    {
        Task<Product> CreateProductAsync(Product product);
    }
}
