﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using AIN.PAAS.ViewModel.Models.Response;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.Repository
{
    public class InventoryAPIRepository : IInventoryAPIRepository
    {
        private string domain;
        private static Random random = new Random();
        public enum AvailableStatus
        {
            InTransit,
            Available,
            UnAvailable
        }
        private readonly IMongoCollection<Hospital> _hospital;
        private readonly IMongoCollection<Site> _site;
        private readonly IMongoCollection<Lab> _lab;
        private readonly IMongoCollection<Location> _location;
        private readonly IMongoCollection<Storage> _storage;
        private readonly IMongoCollection<InventoryItem> _inventoryItem;
        private readonly IMongoCollection<Product> _product;
        private readonly IMongoCollection<TransferRequest> _transfer;
        public InventoryAPIRepository(IAINInventoryDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _hospital = database.GetCollection<Hospital>(settings.HospitalCollectionName);
            _site = database.GetCollection<Site>(settings.SiteCollectionName);
            _lab = database.GetCollection<Lab>(settings.LabCollectionName);
            _location = database.GetCollection<Location>(settings.LocationCollectionName);
            _storage = database.GetCollection<Storage>(settings.StorageCollectionName);
            _inventoryItem = database.GetCollection<InventoryItem>(settings.InventoryCollectionName);
            _product = database.GetCollection<Product>(settings.ProductCollectionName);
            _transfer = database.GetCollection<TransferRequest>(settings.TransferCollectionName);
            domain = (settings.APIDomain);
        }
        public async Task<Hospital> CreateHospitalAsync(Hospital hospitalRequest)
        {
            await _hospital.InsertOneAsync(hospitalRequest);
            return hospitalRequest;
        }
        public async Task<Lab> CreateLabAsync(Lab lab)
        {
            await _lab.InsertOneAsync(lab);
            return lab;
        }
        public async Task<Location> CreateLocationAsync(Location location)
        {
            await _location.InsertOneAsync(location);
            return location;
        }
        public async Task<Product> CreateProductAsync(Product product)
        {
            await _product.InsertOneAsync(product);
            return product;
        }
        public async Task<Site> CreateSiteAsync(Site site)
        {
            await _site.InsertOneAsync(site);
            return site;
        }
        public async Task<Storage> CreateStorageAsync(Storage storage)
        {
            await _storage.InsertOneAsync(storage);
            return storage;
        }
        public async Task<List<HospitalsResponse>> GetHospital()
        {
            List<HospitalsResponse> hospitalResponseList = new List<HospitalsResponse>();
            try
            {
                var hospitals = await _hospital.Find(s => true).ToListAsync();
                var sites = await _site.Find(s => true).ToListAsync();
                if (hospitals != null)
                {
                    foreach (var hospital in hospitals)
                    {
                        HospitalsResponse hospitalsResponse = new HospitalsResponse()
                        {
                            HospitalId = hospital.Id.ToString(),
                            Name = hospital.Name,
                            Sites = sites.Select(e => domain + "/api/sites/" + e.Id).ToArray()
                        };
                        hospitalResponseList.Add(hospitalsResponse);
                    }
                }
                return hospitalResponseList;
            }
            catch (Exception e)
            {
                throw e;
            }
        }              
        public async Task<InventoryItem> GetInventoryByIDStorageID(TransferRequestData transferRequestData, int iterationitem)
        {
            return await _inventoryItem.Find(s => s.Id == transferRequestData.items[iterationitem] && s.StorageId == transferRequestData.SourceId).FirstOrDefaultAsync();
        }
        public async Task<InventoryItem> GetInventoryBySGTIN(string SGTIN)
        {
            return await _inventoryItem.Find(s => s.SGTIN == SGTIN).FirstOrDefaultAsync();
        }
        public async Task<List<InventoryItem>> GetInventoryByStatus(string status)
        {
            return await _inventoryItem.Find(s => s.Status == status).ToListAsync();
        }
        public async Task<LabsResponse> GetLab(string labID)
        {
            LabsResponse labsResponse = null;
            try
            {
                var lab = await _lab.Find(s => s.Id == labID).FirstOrDefaultAsync();
                var locations = await _location.Find(s => s.LabID == labID).ToListAsync();

                if (lab != null)
                {
                    labsResponse = new LabsResponse()
                    {
                        LabId = lab.Id,
                        Name = lab.Name,
                        Locations = locations.Select(e => domain + "/api/locations/" + e.Id).ToArray()
                    };

                }
                return labsResponse;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public async Task<List<Lab>> GetLabs()
        {
            return await _lab.Find(s => true).ToListAsync();
        }  
        public async Task<LocationsResponse> GetLocationsById(string locationId)
        {
            LocationsResponse locationResponse = null;
            try
            {
                var location = await _location.Find(s => s.Id == locationId).FirstOrDefaultAsync();
                var storages = await _storage.Find(s => s.LocationId == locationId).ToListAsync();

                if (location != null)
                {
                    locationResponse = new LocationsResponse()
                    {
                        LocationId = location.Id,
                        Name = location.Name,
                        Storages = storages.Select(e => domain + "/api/storages/" + e.Id).ToArray()
                    };

                }
                return locationResponse;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        
        public async Task<SitesResponse> Getsite(string siteID)
        {
            SitesResponse sitesResponse = null;
            try
            {
                var sites = await _site.Find(s => s.Id == siteID).FirstOrDefaultAsync();
                var labs = await _lab.Find(s => s.SiteID == siteID).ToListAsync();

                if (sites != null)
                {
                    sitesResponse = new SitesResponse()
                    {
                        SiteId = sites.Id,
                        Name = sites.Name,
                        Labs = labs.Select(e => domain + "/api/labs/" + e.Id).ToArray()
                    };
                }
                return sitesResponse;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public async Task<List<Site>> Getsites()
        {
            return await _site.Find(s => true).ToListAsync();
        }

        public async Task<List<Storage>> GetStorages()
        {
            return await _storage.Find(s => true).ToListAsync();
        }
        public async Task<StoragesResponse> GetStoragesById(string storageId)
        {
            StoragesResponse storageResponse = null;
            try
            {
                var storage = await _storage.Find(s => s.Id == storageId).FirstOrDefaultAsync();
                var inventoryItems = await _inventoryItem.Find(s => s.StorageId == storageId).ToListAsync();

                if (storage != null)
                {
                    storageResponse = new StoragesResponse()
                    {
                        StorageId = storage.Id,
                        Name = storage.Name,
                        Inventory = inventoryItems.Select(e => domain + "/api/inventory/" + e.Id).ToArray()
                    };

                }
                return storageResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<CheckInResponse> InventoryCheckIn(CheckInRequest checkInRequest)
        {
            var results = new InventoryItem();
            try
            {
                if (checkInRequest.AutoId)
                {
                    checkInRequest.SGTIN = new string[checkInRequest.Quantity];
                    const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                    for (var i = 0; i < checkInRequest.Quantity; i++)
                    {
                        checkInRequest.SGTIN[i] = new string(Enumerable.Repeat(chars, 24)
                        .Select(s => s[random.Next(s.Length)]).ToArray());
                    }
                }
                foreach (var sgtin in checkInRequest.SGTIN)
                {
                    InventoryItem inventoryItem = new InventoryItem()
                    {
                        AutoId = checkInRequest.AutoId,
                        ProductId = checkInRequest.ProductId,
                        StorageId = checkInRequest.StorageId,
                        ExpiryDate = checkInRequest.ExpiryDate,
                        LotNumber = checkInRequest.LotNumber,
                        Quantity = checkInRequest.Quantity,
                        //SGTIN = new string[] { sgtin },
                        SGTIN = sgtin,
                        Remarks = checkInRequest.Remarks,
                        Status = AvailableStatus.Available.ToString(),
                        CreatedDate = DateTime.Now
                    };
                    results = await InventoryCheckIn(inventoryItem);
                }
                CheckInResponse checkinResponse = new CheckInResponse()
                {
                    Status = "success",
                    SGTIN = checkInRequest.SGTIN,
                    Product = domain + "/api/products/" + checkInRequest.ProductId,
                    ExpiryDate = checkInRequest.ExpiryDate,
                    Lot = checkInRequest.LotNumber,
                    Storage = domain + "/api/Storages/" + checkInRequest.StorageId
                };
                if (results != null)
                {
                    return checkinResponse;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<InventoryItem> InventoryCheckOut(CheckOutRequest checkOutRequest)
        {
            InventoryItem checkOutItem = new InventoryItem();
            try
            {
                for (var j = 0; j < checkOutRequest.SGTIN.Length; j++)
                {
                    checkOutItem = await GetInventoryBySGTIN(checkOutRequest.SGTIN[j]);
                    if (checkOutItem == null)
                    {
                        return null;
                    }
                    else
                    {
                        checkOutItem.Status = AvailableStatus.UnAvailable.ToString();
                        await CheckoutUpdateAsync(checkOutItem.Id, checkOutItem);
                    }
                }
                return checkOutItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task CheckoutUpdateAsync(string id, InventoryItem checkoutinventory)
        {
            await _inventoryItem.ReplaceOneAsync(s => s.Id == id, checkoutinventory);
        }
        public async Task<TransferRequestData> ItemTransfer(TransferRequestData transferRequestData)
        {
            try
            {
                for (var j = 0; j < transferRequestData.items.Length; j++)
                {
                    var transferItem = await GetInventoryByIDStorageID(transferRequestData, j);
                    if (transferItem != null)
                    {
                        if (!(transferRequestData.Status.Equals("Approved", StringComparison.OrdinalIgnoreCase)) && !(transferRequestData.Status.Equals("Rejected", StringComparison.OrdinalIgnoreCase))) // update CheckInStatus with Pending approval
                        {
                            transferItem.Status = AvailableStatus.InTransit.ToString();
                            await CheckoutUpdateAsync(transferItem.Id, transferItem);

                            TransferRequest dbtransferRequest = new TransferRequest()
                            {
                                Items = transferRequestData.items[j],
                                SourceId = (transferRequestData.SourceId),
                                DestinationId = transferRequestData.DestinationId,
                                Requester = transferRequestData.Requester,
                                RequestedDate = transferRequestData.RequestedDate,
                                Approver = transferRequestData.Approver,
                                Status = transferRequestData.Status,
                                Comments = transferRequestData.Comments,
                                CreatedDate = DateTime.Now,
                            };
                            await ItemTransferData(dbtransferRequest);
                        }

                        else // approved or Rejected case
                        {
                            if (transferRequestData.Status.Equals("Approved", StringComparison.OrdinalIgnoreCase))
                            {
                                transferItem.Status = AvailableStatus.Available.ToString();
                                transferItem.StorageId = transferRequestData.DestinationId;
                                await CheckoutUpdateAsync(transferItem.Id, transferItem);

                                TransferRequest dbtransferRequest = new TransferRequest()
                                {
                                    Items = transferRequestData.items[j],
                                    SourceId = (transferRequestData.SourceId),
                                    DestinationId = transferRequestData.DestinationId,
                                    Requester = transferRequestData.Requester,
                                    RequestedDate = transferRequestData.RequestedDate,
                                    Approver = transferRequestData.Approver,
                                    Status = transferRequestData.Status,
                                    Comments = transferRequestData.Comments,
                                    CreatedDate = DateTime.Now,
                                };
                                await ItemTransferData(dbtransferRequest);
                            }

                            else if (transferRequestData.Status.Equals("Rejected", StringComparison.OrdinalIgnoreCase))
                            {
                                transferItem.Status = AvailableStatus.Available.ToString();
                                await CheckoutUpdateAsync(transferItem.Id, transferItem);

                                TransferRequest dbtransferRequest = new TransferRequest()
                                {
                                    Items = transferRequestData.items[j],
                                    SourceId = (transferRequestData.SourceId),
                                    DestinationId = transferRequestData.DestinationId,
                                    Requester = transferRequestData.Requester,
                                    RequestedDate = transferRequestData.RequestedDate,
                                    Approver = transferRequestData.Approver,
                                    Status = transferRequestData.Status,
                                    Comments = transferRequestData.Comments,
                                    CreatedDate = DateTime.Now,
                                };
                                await ItemTransferData(dbtransferRequest);
                            }
                        }
                    }
                    else
                    {
                        return null;
                    }
                }

                return transferRequestData;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public async Task<InventoryItem> InventoryCheckIn(InventoryItem inventoryItem)
        {
            await _inventoryItem.InsertOneAsync(inventoryItem);
            return inventoryItem;
        }
        public async Task<TransferRequest> ItemTransferData(TransferRequest transferRequest)
        {
            await _transfer.InsertOneAsync(transferRequest);
            return transferRequest;
        }
    }
}
