﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.Repository
{
    public class InventoryRepository : IInventoryRepository
    {
        private static Random random = new Random();
        public enum AvailableStatus
        {
            InTransit,
            Available,
            UnAvailable
        }      
        private readonly IMongoCollection<InventoryItem> _inventoryItem;       
        private readonly IMongoCollection<TransferRequest> _transfer;
        private readonly RegionConfigs _regionConfigs;
        public InventoryRepository(IAINInventoryDatabaseSettings settings, IOptions<RegionConfigs> regionConfigs)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);            
            _inventoryItem = database.GetCollection<InventoryItem>(settings.InventoryCollectionName);            
            _transfer = database.GetCollection<TransferRequest>(settings.TransferCollectionName);
            _regionConfigs = regionConfigs.Value;
        }

        public async Task<List<InventoryItem>> GetInventoryByStatus(string status)
        {
            return await _inventoryItem.Find(s => s.Status == status).ToListAsync();
        }

        public async Task<CheckInResponse> InventoryCheckIn(CheckInRequest checkInRequest)
        {
            var results = new InventoryItem();
            try
            {
                if (checkInRequest.AutoId)
                {
                    checkInRequest.SGTIN = new string[checkInRequest.Quantity];
                    const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                    for (var i = 0; i < checkInRequest.Quantity; i++)
                    {
                        checkInRequest.SGTIN[i] = new string(Enumerable.Repeat(chars, 24)
                        .Select(s => s[random.Next(s.Length)]).ToArray());
                    }
                }
                foreach (var sgtin in checkInRequest.SGTIN)
                {
                    InventoryItem inventoryItem = new InventoryItem()
                    {
                        AutoId = checkInRequest.AutoId,
                        ProductId = checkInRequest.ProductId,
                        StorageId = checkInRequest.StorageId,
                        ExpiryDate = checkInRequest.ExpiryDate,
                        LotNumber = checkInRequest.LotNumber,
                        Quantity = checkInRequest.Quantity,
                        //SGTIN = new string[] { sgtin },
                        SGTIN = sgtin,
                        Remarks = checkInRequest.Remarks,
                        Status = AvailableStatus.Available.ToString(),
                        CreatedDate = DateTime.Now
                    };
                    results = await InventoryCheckIn(inventoryItem);
                }
                CheckInResponse checkinResponse = new CheckInResponse()
                {
                    Status = "success",
                    SGTIN = checkInRequest.SGTIN,
                    Product = _regionConfigs.APIDomain + "/api/products/" + checkInRequest.ProductId,
                    ExpiryDate = checkInRequest.ExpiryDate,
                    Lot = checkInRequest.LotNumber,
                    Storage = _regionConfigs.APIDomain + "/api/Storages/" + checkInRequest.StorageId
                };
                if (results != null)
                {
                    return checkinResponse;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<InventoryItem> InventoryCheckOut(CheckOutRequest checkOutRequest)
        {
            InventoryItem checkOutItem = new InventoryItem();
            try
            {
                for (var j = 0; j < checkOutRequest.SGTIN.Length; j++)
                {
                    checkOutItem = await GetInventoryBySGTIN(checkOutRequest.SGTIN[j]);
                    if (checkOutItem == null)
                    {
                        return null;
                    }
                    else
                    {
                        checkOutItem.Status = AvailableStatus.UnAvailable.ToString();
                        await CheckoutUpdateAsync(checkOutItem.Id, checkOutItem);
                    }
                }
                return checkOutItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<TransferRequestData> ItemTransfer(TransferRequestData transferRequestData)
        {
            try
            {
                for (var j = 0; j < transferRequestData.items.Length; j++)
                {
                    var transferItem = await GetInventoryByIDStorageID(transferRequestData, j);
                    if (transferItem != null)
                    {
                        if (!(transferRequestData.Status.Equals("Approved", StringComparison.OrdinalIgnoreCase)) && !(transferRequestData.Status.Equals("Rejected", StringComparison.OrdinalIgnoreCase))) // update CheckInStatus with Pending approval
                        {
                            transferItem.Status = AvailableStatus.InTransit.ToString();
                            await CheckoutUpdateAsync(transferItem.Id, transferItem);

                            TransferRequest dbtransferRequest = new TransferRequest()
                            {
                                Items = transferRequestData.items[j],
                                SourceId = (transferRequestData.SourceId),
                                DestinationId = transferRequestData.DestinationId,
                                Requester = transferRequestData.Requester,
                                RequestedDate = transferRequestData.RequestedDate,
                                Approver = transferRequestData.Approver,
                                Status = transferRequestData.Status,
                                Comments = transferRequestData.Comments,
                                CreatedDate = DateTime.Now,
                            };
                            await ItemTransferData(dbtransferRequest);
                        }

                        else // approved or Rejected case
                        {
                            if (transferRequestData.Status.Equals("Approved", StringComparison.OrdinalIgnoreCase))
                            {
                                transferItem.Status = AvailableStatus.Available.ToString();
                                transferItem.StorageId = transferRequestData.DestinationId;
                                await CheckoutUpdateAsync(transferItem.Id, transferItem);

                                TransferRequest dbtransferRequest = new TransferRequest()
                                {
                                    Items = transferRequestData.items[j],
                                    SourceId = (transferRequestData.SourceId),
                                    DestinationId = transferRequestData.DestinationId,
                                    Requester = transferRequestData.Requester,
                                    RequestedDate = transferRequestData.RequestedDate,
                                    Approver = transferRequestData.Approver,
                                    Status = transferRequestData.Status,
                                    Comments = transferRequestData.Comments,
                                    CreatedDate = DateTime.Now,
                                };
                                await ItemTransferData(dbtransferRequest);
                            }

                            else if (transferRequestData.Status.Equals("Rejected", StringComparison.OrdinalIgnoreCase))
                            {
                                transferItem.Status = AvailableStatus.Available.ToString();
                                await CheckoutUpdateAsync(transferItem.Id, transferItem);

                                TransferRequest dbtransferRequest = new TransferRequest()
                                {
                                    Items = transferRequestData.items[j],
                                    SourceId = (transferRequestData.SourceId),
                                    DestinationId = transferRequestData.DestinationId,
                                    Requester = transferRequestData.Requester,
                                    RequestedDate = transferRequestData.RequestedDate,
                                    Approver = transferRequestData.Approver,
                                    Status = transferRequestData.Status,
                                    Comments = transferRequestData.Comments,
                                    CreatedDate = DateTime.Now,
                                };
                                await ItemTransferData(dbtransferRequest);
                            }
                        }
                    }
                    else
                    {
                        return null;
                    }
                }

                return transferRequestData;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public async Task CheckoutUpdateAsync(string id, InventoryItem checkoutinventory)
        {
            await _inventoryItem.ReplaceOneAsync(s => s.Id == id, checkoutinventory);
        }
        public async Task<InventoryItem> InventoryCheckIn(InventoryItem inventoryItem)
        {
            await _inventoryItem.InsertOneAsync(inventoryItem);
            return inventoryItem;
        }
        public async Task<TransferRequest> ItemTransferData(TransferRequest transferRequest)
        {
            await _transfer.InsertOneAsync(transferRequest);
            return transferRequest;
        }
        public async Task<InventoryItem> GetInventoryBySGTIN(string SGTIN)
        {
            return await _inventoryItem.Find(s => s.SGTIN == SGTIN).FirstOrDefaultAsync();
        }
        public async Task<InventoryItem> GetInventoryByIDStorageID(TransferRequestData transferRequestData, int iterationitem)
        {
            return await _inventoryItem.Find(s => s.Id == transferRequestData.items[iterationitem] && s.StorageId == transferRequestData.SourceId).FirstOrDefaultAsync();
        }
    }
}
