﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.Services
{
    public class ProductsService : IProductsService
    {
        private IProductsRepository _productsRepository;
        public ProductsService(IProductsRepository productsRepository)
        {
            _productsRepository = productsRepository;
        }
        public async Task<Product> CreateProductAsync(Product product)
        {
            return await _productsRepository.CreateProductAsync(product);
        }
    }
}
