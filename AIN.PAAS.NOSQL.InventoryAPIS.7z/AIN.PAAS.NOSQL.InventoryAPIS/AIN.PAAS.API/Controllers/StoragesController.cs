﻿using AIN.PAAS.Helper.Constants;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;

namespace AIN.PAAS.API.Controllers
{
    [Route(CommonConstants.Storage.LocationsAPIControllerRoute)]
    [ApiController]
    public class StoragesController : ControllerBase
    {
        private IStorageServices _storageServices;
        public StoragesController(IStorageServices storageServices)
        {
            _storageServices = storageServices;
        }

        [HttpPost]        
        public async Task<IActionResult> Post(Storage storage)
        {
            try
            {
                var results = await _storageServices.CreateStorageAsync(storage);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpGet]
        //[Route(CommonConstants.Storage.AllStorages)]
        public async Task<ActionResult<Storage>> Get()
        {
            try
            {
                var storages = await _storageServices.GetStorages();
                if (storages != null)
                {
                    return new OkObjectResult(storages);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpGet]
        [Route(CommonConstants.Storage.GetStorageById)]
        public async Task<ActionResult<StoragesResponse>> Get(string storageId)
        {
            try
            {
                var storageResponse = await _storageServices.GetStoragesById(storageId);

                if (storageResponse != null)
                {
                    return new OkObjectResult(storageResponse);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

    }
}
