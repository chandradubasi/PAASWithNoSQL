﻿using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace AIN.PAAS.API.Controllers
{
    [Route("api/")]
    [ApiController]
    public class InventoryControllerWithRef : ControllerBase
    {
        private IInventoryAPIServices _inventoryAPIServices;

        public InventoryControllerWithRef(IInventoryAPIServices inventoryAPIServices)
        {
            _inventoryAPIServices = inventoryAPIServices;
        }

        [HttpPost("createhospital")]       
        public async Task<IActionResult> CreateHospital(Hospital hospital)
        {
            try
            {
                var results = await _inventoryAPIServices.CreateHospitalAsync(hospital);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPost("createsite")]
        public async Task<IActionResult> CreateSite(Site site)
        {
            try
            {
                var results = await _inventoryAPIServices.CreateSiteAsync(site);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPost("createlab")]
        public async Task<IActionResult> CreateLab(Lab lab)
        {
            try
            {
                var results = await _inventoryAPIServices.CreateLabAsync(lab);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpGet("hospitals")]
        public async Task<ActionResult<IEnumerable<HospitalsResponse>>> GetHospital()
        {
            try
            {
                var hospitalResponseList = await _inventoryAPIServices.GetHospital();
                if (hospitalResponseList != null)
                {
                    return new OkObjectResult(hospitalResponseList);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpGet("getallsites")]
        public async Task<ActionResult<Site>> Getsites()
        {
            try
            {
                var sites = await _inventoryAPIServices.Getsites();
                if (sites != null)
                {
                    return new OkObjectResult(sites);
                }
                else
                {
                    return new BadRequestResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpGet("sites/{siteId}")]
        public async Task<ActionResult<SitesResponse>> GetSiteById(string siteId)
        {
            try
            {
                var sitesResponseList = await _inventoryAPIServices.Getsite(siteId);
                if (sitesResponseList != null)
                {
                    return new OkObjectResult(sitesResponseList);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpGet("getalllabs")]
        public async Task<ActionResult<Lab>> GetLabs()
        {
            try
            {
                var labs = await _inventoryAPIServices.GetLabs();
                if (labs != null)
                {
                    return new OkObjectResult(labs);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpGet("labs/{labID}")]
        public async Task<ActionResult<LabsResponse>> GetLabByID(string labID)
        {
            try
            {
                var labsResponseList = await _inventoryAPIServices.GetLab(labID);
                if (labsResponseList != null)
                {
                    return new OkObjectResult(labsResponseList);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPost("createlocation")]
        public async Task<IActionResult> CreateLocation(Location location)
        {
            try
            {
                var results = await _inventoryAPIServices.CreateLocationAsync(location);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }
        [HttpGet("locations/{locationID}")]
        public async Task<ActionResult<LocationsResponse>> GetLocationByID(string locationID)
        {
            try
            {
                var locationResponse = await _inventoryAPIServices.GetLocationsById(locationID);
                if (locationResponse != null)
                {
                    return new OkObjectResult(locationResponse);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPost("createstorage")]
        public async Task<IActionResult> CreateStorage(Storage storage)
        {
            try
            {
                var results = await _inventoryAPIServices.CreateStorageAsync(storage);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpGet("getallstorages")]
        public async Task<ActionResult<Storage>> GetStorages()
        {
            try
            {
                var storages = await _inventoryAPIServices.GetStorages();
                if (storages != null)
                {
                    return new OkObjectResult(storages);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpGet("storages/{storageID}")]
        public async Task<ActionResult<StoragesResponse>> GetStorageByID(string storageID)
        {
            try
            {
                var storageResponse = await _inventoryAPIServices.GetStoragesById(storageID);

                if (storageResponse != null)
                {
                    return new OkObjectResult(storageResponse);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpGet("inventorylist/{status}")]
        public async Task<ActionResult<IEnumerable<InventoryItem>>> GetInventoryByStatus(string status)
        {
            try
            {
                var inventorylist = await _inventoryAPIServices.GetInventoryByStatus(status);
                if (inventorylist == null)
                {
                    return new NotFoundResult();
                }
                return new OkObjectResult(inventorylist);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPost("createproduct")]
        public async Task<IActionResult> CreateProduct(Product product)
        {
            try
            {
                var results = await _inventoryAPIServices.CreateProductAsync(product);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPost("workflows/CheckIn")]
        public async Task<IActionResult> InventoryCheckIn(CheckInRequest checkInRequest)
        {
            try
            {
                var checkinResponse = await _inventoryAPIServices.InventoryCheckIn(checkInRequest);
                if (checkinResponse == null)
                {
                    return new BadRequestResult();
                }
                else
                {
                    return new OkObjectResult(checkinResponse);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPut("workflows/CheckOut")]
        public async Task<IActionResult> InventoryCheckOut(CheckOutRequest checkOutRequest)
        {
            try
            {
                var checkOutItem = await _inventoryAPIServices.InventoryCheckOut(checkOutRequest);
                if (checkOutItem == null)
                {
                    return new BadRequestResult();
                }
                else
                {
                    return new OkObjectResult(StatusCodes.Status200OK);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }

        [HttpPut("workflows/transfer")]
        public async Task<IActionResult> InventoryTransfer(TransferRequestData transferRequestData)
        {
            var transferResponse = await _inventoryAPIServices.ItemTransfer(transferRequestData);
            try
            {
                if (transferResponse == null)
                {
                    return new BadRequestResult();
                }
                else
                {
                    return new OkObjectResult(transferResponse);
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "Internal Server Error");
            }
        }
    }
}
