﻿using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.IRepository
{
    public interface IInventoryRepository
    {
        Task<CheckInResponse> InventoryCheckIn(CheckInRequest checkInRequest);
        Task<List<InventoryItem>> GetInventoryByStatus(string status);
        Task<InventoryItem> InventoryCheckOut(CheckOutRequest checkOutRequest);
        Task<TransferRequestData> ItemTransfer(TransferRequestData transferRequestData);

    }
}
