﻿using AIN.PAAS.Helper.Constants;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Request;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace AIN.PAAS.API.Controllers
{
    [Route(CommonConstants.Inventory.InventoryAPIControllerRoute)]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private IInventoryServices _inventoryServices;

        public InventoryController(IInventoryServices inventoryServices)
        {
            _inventoryServices = inventoryServices;
        }

        [HttpGet]
        [Route(CommonConstants.Inventory.GetInventoryByStatus)]
        public async Task<ActionResult<IEnumerable<InventoryItem>>> GetInventoryByStatus(string status)
        {
            try
            {
                var inventorylist = await _inventoryServices.GetInventoryByStatus(status);
                if (inventorylist == null)
                {
                    return new NotFoundResult();
                }
                return new OkObjectResult(inventorylist);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpPost]
        [Route(CommonConstants.Inventory.CreateInventoryRoute)]
        public async Task<IActionResult> InventoryCheckIn(CheckInRequest checkInRequest)
        {
            try
            {
                var checkinResponse = await _inventoryServices.InventoryCheckIn(checkInRequest);
                if (checkinResponse == null)
                {
                    return new BadRequestResult();
                }
                else
                {
                    return new OkObjectResult(checkinResponse);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpPut]
        [Route(CommonConstants.Inventory.CheckOutInventoryRoute)]
        public async Task<IActionResult> InventoryCheckOut(CheckOutRequest checkOutRequest)
        {
            try
            {
                var checkOutItem = await _inventoryServices.InventoryCheckOut(checkOutRequest);
                if (checkOutItem == null)
                {
                    return new BadRequestResult();
                }
                else
                {
                    return new OkObjectResult(StatusCodes.Status200OK);
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpPut]
        [Route(CommonConstants.Inventory.InventoryTransfer)]
        public async Task<IActionResult> InventoryTransfer(TransferRequestData transferRequestData)
        {
            var transferResponse = await _inventoryServices.ItemTransfer(transferRequestData);
            try
            {
                if (transferResponse == null)
                {
                    return new BadRequestResult();
                }
                else
                {
                    return new OkObjectResult(transferResponse);
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }
    }
}
