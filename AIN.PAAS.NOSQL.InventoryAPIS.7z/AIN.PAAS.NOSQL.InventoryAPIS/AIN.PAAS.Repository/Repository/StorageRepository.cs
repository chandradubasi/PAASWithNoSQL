﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.Repository
{
    public class StorageRepository : IStorageRepository
    {
        private readonly IMongoCollection<Storage> _storage;
        private readonly IMongoCollection<InventoryItem> _inventoryItem;
        private readonly RegionConfigs _regionConfigs;
        public StorageRepository(IAINInventoryDatabaseSettings settings, IOptions<RegionConfigs> regionConfigs)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _storage = database.GetCollection<Storage>(settings.StorageCollectionName);
            _inventoryItem = database.GetCollection<InventoryItem>(settings.InventoryCollectionName);
            _regionConfigs = regionConfigs.Value;
        }
        public async Task<Storage> CreateStorageAsync(Storage storage)
        {
            await _storage.InsertOneAsync(storage);
            return storage;
        }

        public async Task<List<Storage>> GetStorages()
        {
            return await _storage.Find(s => true).ToListAsync();
        }

        public async Task<StoragesResponse> GetStoragesById(string storageId)
        {
            StoragesResponse storageResponse = null;
            try
            {
                var storage = await _storage.Find(s => s.Id == storageId).FirstOrDefaultAsync();
                var inventoryItems = await _inventoryItem.Find(s => s.StorageId == storageId).ToListAsync();

                if (storage != null)
                {
                    storageResponse = new StoragesResponse()
                    {
                        StorageId = storage.Id,
                        Name = storage.Name,
                        Inventory = inventoryItems.Select(e => _regionConfigs.APIDomain + "/api/inventory/" + e.Id).ToArray()
                    };

                }
                return storageResponse;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
