﻿using AIN.PAAS.Helper.Constants;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Threading.Tasks;

namespace AIN.PAAS.API.Controllers
{
    [Route(CommonConstants.Lab.LabAPIControllerRoute)]
    [ApiController]
    public class LabsController : ControllerBase
    {
        private ILabsService _labsService;

        public LabsController(ILabsService labsService)
        {
            _labsService = labsService;
        }

        [HttpPost]        
        public async Task<IActionResult> Post(Lab lab)
        {
            try
            {
                var results = await _labsService.CreateLabAsync(lab);
                if (results.Id != null)
                {
                    return new OkObjectResult(results);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpGet]
        //[Route(CommonConstants.Lab.AllLabs)]
        public async Task<ActionResult<Lab>> Get()
        {
            try
            {
                var labs = await _labsService.GetLabs();
                if (labs != null)
                {
                    return new OkObjectResult(labs);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }

        [HttpGet()]
        [Route(CommonConstants.Lab.GetLabById)]
        public async Task<ActionResult<LabsResponse>> Get(string labId)
        {
            try
            {
                var labsResponseList = await _labsService.GetLab(labId);
                if (labsResponseList != null)
                {
                    return new OkObjectResult(labsResponseList);
                }
                else
                {
                    return new NotFoundResult();
                }
            }
            catch (Exception e)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, CommonConstants.APIConstant.InternalServerError);
            }
        }
    }
}
