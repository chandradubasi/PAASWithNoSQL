﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.Services.IServices;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AIN.PAAS.Services.Services
{
    public class LabsService : ILabsService
    {
        private ILabsRepository _labsRepository;
        public LabsService(ILabsRepository labsRepository)
        {
            _labsRepository = labsRepository;
        }

        public async Task<Lab> CreateLabAsync(Lab lab)
        {
            return await _labsRepository.CreateLabAsync(lab);
        }

        public async Task<LabsResponse> GetLab(string labID)
        {
            return await _labsRepository.GetLab(labID);
        }

        public async Task<List<Lab>> GetLabs()
        {
            return await _labsRepository.GetLabs();
        }
    }
}
