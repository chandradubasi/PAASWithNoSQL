﻿using AIN.PAAS.Repository.IRepository;
using AIN.PAAS.ViewModel.Models;
using AIN.PAAS.ViewModel.Models.Response;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AIN.PAAS.Repository.Repository
{
    public class HospitalRepository : IHospitalRepository
    {
        private readonly IMongoCollection<Hospital> _hospital;
        private readonly IMongoCollection<Site> _site;
        private readonly RegionConfigs _regionConfigs;
        public HospitalRepository(IAINInventoryDatabaseSettings settings , IOptions<RegionConfigs> regionConfigs)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);
            _hospital = database.GetCollection<Hospital>(settings.HospitalCollectionName);
            _site = database.GetCollection<Site>(settings.SiteCollectionName);            
            _regionConfigs = regionConfigs.Value;            

        }

        public async Task<Hospital> CreateHospitalAsync(Hospital hospitalRequest)
        {
            await _hospital.InsertOneAsync(hospitalRequest);
            return hospitalRequest;
        }

        public async Task<List<HospitalsResponse>> GetHospital()
        {
            List<HospitalsResponse> hospitalResponseList = new List<HospitalsResponse>();
            try
            {
                var hospitals = await _hospital.Find(s => true).ToListAsync();
                var sites = await _site.Find(s => true).ToListAsync();
                if (hospitals != null)
                {
                    foreach (var hospital in hospitals)
                    {
                        HospitalsResponse hospitalsResponse = new HospitalsResponse()
                        {
                            HospitalId = hospital.Id.ToString(),
                            Name = hospital.Name,
                            Sites = sites.Select(e => _regionConfigs.APIDomain + "/api/sites/" + e.Id).ToArray()
                        };
                        hospitalResponseList.Add(hospitalsResponse);
                    }
                }
                return hospitalResponseList;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
