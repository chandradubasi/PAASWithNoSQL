using System;
using Xunit;

namespace AIN.PAAS.API.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            // needs to be done
        }
    }
}
